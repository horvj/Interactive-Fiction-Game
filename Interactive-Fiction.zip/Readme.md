# Project Name
Project 1 for MSCH-C220 at Indiana University
A simple STNG Interactive Fiction Game

## Implementation
Created using Python 3.10. The story was created in Twine 2.7.

## What Makes this a Game?
You can win the game and lose the game and for
a for fans of fantasy rpg it can be fun!

## References
Zork I
World of Warcraft

## Future Development
TBD

## Created by
Jack Horvath