import json

inventory = []
visits = []
counter = 0


def add_item(item):
  inventory.append(item)


def find_passage(game, pid):
  if "passages" in game:
    for passage in game["passages"]:
      if pid == passage["pid"]:
        return passage
  return {}


f = open('game.json')
game = json.load(f)
f.close()


def render(game, passage):
  if "name" in passage:
    print(passage["name"])
    print("")
    print("Moves: " + str(counter))
  if (passage["name"]) in visits:
    pass
  else:
    visits.append(passage["name"])

  if "inventory" in passage:
    add_item(passage["inventory"])
  print("Number of unique passages visited: " + str(len(visits)))
  print("Current Inventory: " + str(inventory))
  print("\n")
  if "text" in passage:
    print(passage["text"] + "\n")
  if "links" in passage:
    for l in passage["links"]:
      if "requires" in l and l["requires"] in inventory:
        print(l["selection"] + ". " + l["label"])
      elif "requires" not in l:
        print(l["selection"] + ". " + l["label"])
      if "marker" in l:
        inventory.remove("Pie&Ale")


def get_input(passage):
  while True:
    response = input("What do you want to do? (Type quit to exit): ")
    if response.strip().upper() == "QUIT":
      return "QUIT"
    if "links" in passage:
      for l in passage["links"]:

        if l["selection"] == response:
          return l["pid"]


def update(game, response):
  return response


pid = 0
passage = {}
response = ""
if "startnode" in game:
  pid = game["startnode"]

while True:
  passage = find_passage(game, pid)
  if passage["name"] == "Beginning":
    inventory = []
    counter = 0
    visits = []
  render(game, passage)
  response = get_input(passage)
  if response == "QUIT":
    break
  pid = update(game, response)
  print("")
  print("")
  counter = counter + 1

print("Thanks for playing!")
